#include "GDCF.h"
#include "pico/multicore.h"
GDCFFabric fabric(1,1);
volatile bool injectFlag=false; volatile float sensorValue=0;
void core1_code(){
  while(1){
    int raw=analogRead(26);
    sensorValue=raw/100.0f;
    digitalWrite(2,HIGH); injectFlag=true; delay(10); digitalWrite(2,LOW);
    delay(1000);
  }
}
void setup(){
  Serial.begin(115200); fabric.setNode(0,0,PRIM_IDENTITY); fabric.setActivityPin(0,0,0);
  pinMode(2,OUTPUT); digitalWrite(2,LOW);
  multicore_launch_core1(core1_code); fabric.begin();
}
void loop(){
  fabric.lock();
  if(injectFlag){ injectFlag=false; fabric.inject(0,0,3,GDCFToken(true,0,0,sensorValue,0,0,0,0)); }
  fabric.update(); fabric.unlock();
  if(fabric.nodes[0].hasOutput()){ Serial.println(fabric.nodes[0].consumeOutput().data); }
  delay(1);
}
