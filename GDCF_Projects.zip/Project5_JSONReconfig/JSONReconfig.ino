#include "GDCF.h"
#include <ArduinoJson.h>
GDCFFabric* fabric=nullptr;
void setup(){ Serial.begin(115200); }
void loop(){
  if(Serial.available()){
    String json=Serial.readStringUntil("\n");
    StaticJsonDocument<256> doc;
    if(deserializeJson(doc,json)==DeserializationError::Ok){
      JsonArray arr=doc.as<JsonArray>();
      int maxX=0,maxY=0;
      for(JsonObject obj:arr){ int x=obj["x"]; if(x>maxX)maxX=x; int y=obj["y"]; if(y>maxY)maxY=y; }
      if(fabric) delete fabric;
      fabric=new GDCFFabric(maxX+1,maxY+1);
      for(JsonObject obj:arr){
        String op=obj["op"];
        GDCFPrimitive prim=(op=="MAC")?PRIM_MAC:(op=="RELU")?PRIM_RELU:PRIM_IDENTITY;
        fabric->setNode(obj["x"],obj["y"],prim);
      }
      fabric->autoActivityPins(10); fabric->begin();
      Serial.println("Fabric reconfigured.");
    }
  }
  if(fabric) fabric->update();
  delay(5);
}
