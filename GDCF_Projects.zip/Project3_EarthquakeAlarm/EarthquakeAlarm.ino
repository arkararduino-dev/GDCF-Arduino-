#include "GDCF.h"
GDCFFabric fabric(2,1);
void setup(){
  Serial.begin(115200);
  fabric.setNode(0,0,PRIM_MAC); fabric.setNode(1,0,PRIM_IDENTITY);
  fabric.setActivityPin(0,0,0); fabric.setOutputPulsePin(1,0,6);
  fabric.begin();
}
void loop(){
  static unsigned long last=0;
  if(millis()-last>50){
    last=millis();
    int raw=analogRead(26);
    float energy=abs(raw-2048)/100.0f;
    fabric.inject(0,0,3,GDCFToken(true,0,0,energy,0,0,0,0));
    fabric.inject(0,0,0,GDCFToken(true,0,0,6.0f,0,0,0,0));
  }
  fabric.update();
  if(fabric.nodes[1].hasOutput()){
    GDCFToken res=fabric.nodes[1].consumeOutput();
    if(res.data>0){ digitalWrite(LED_BUILTIN,HIGH); delay(200); digitalWrite(LED_BUILTIN,LOW); Serial.println("Earthquake Warning!"); }
  }
}
