#include "GDCF.h"
GDCFFabric fabric(1,1);
void runTest(bool validTokens){
  fabric.nodes[0]=GDCNode(); fabric.nodes[0].setup(0,0,PRIM_MAC); fabric.nodes[0].pin_act=0; pinMode(0,OUTPUT);
  for(int i=0;i<10;i++){
    bool valid=validTokens?true:(i>=5?false:true);
    fabric.inject(0,0,3,GDCFToken(valid,0,0,2.0f,0,0,0,0));
    fabric.inject(0,0,0,GDCFToken(true,0,0,3.0f,0,0,0,0));
  }
  while(!fabric.nodes[0].buf_w.empty()||!fabric.nodes[0].buf_n.empty()) fabric.update();
  Serial.printf("%s: executed=%d, skipped=%d\n", validTokens?"Valid":"Sparse", fabric.nodes[0].ops_done, fabric.nodes[0].ops_skip);
}
void setup(){ Serial.begin(115200); runTest(true); runTest(false); }
void loop(){}
