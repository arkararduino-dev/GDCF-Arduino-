#include "GDCF.h"
GDCFFabric fabric(2,2);
void setup(){
  Serial.begin(115200);
  fabric.setNode(0,0,PRIM_COUNTER); fabric.nodes[0].max_cnt=10;
  fabric.setNode(1,0,PRIM_IDENTITY); fabric.setNode(0,1,PRIM_IDENTITY); fabric.setNode(1,1,PRIM_IDENTITY);
  fabric.autoActivityPins(0);
  fabric.inject(0,0,3,GDCFToken(true,0,0,0.0f,0,0,0,0));
  fabric.begin();
}
void loop(){
  fabric.update();
  for(int i=0;i<4;i++) if(fabric.nodes[i].hasOutput()) Serial.printf("Node %d: %.1f\n",i,fabric.nodes[i].consumeOutput().data);
  delay(5);
}
