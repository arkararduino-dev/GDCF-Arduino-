#include "GDCF.h"
GDCFFabric fabric(2,2);
void setup(){
  Serial.begin(115200);
  for(int y=0;y<2;y++) for(int x=0;x<2;x++) fabric.setNode(x,y,PRIM_MAC);
  fabric.autoActivityPins(0);
  fabric.begin();
  fabric.inject(0,0,0,GDCFToken(true,0,0,1.0f,0,0,0,0));
  fabric.inject(0,0,3,GDCFToken(true,0,0,5.0f,0,0,0,0));
  fabric.inject(1,0,0,GDCFToken(true,0,0,2.0f,0,0,0,0));
  fabric.inject(1,0,3,GDCFToken(true,0,0,6.0f,0,0,0,0));
  fabric.inject(0,1,0,GDCFToken(true,0,0,3.0f,0,0,0,0));
  fabric.inject(0,1,3,GDCFToken(true,0,0,7.0f,0,0,0,0));
  fabric.inject(1,1,0,GDCFToken(true,0,0,4.0f,0,0,0,0));
  fabric.inject(1,1,3,GDCFToken(true,0,0,8.0f,0,0,0,0));
}
void loop(){
  fabric.update();
  for(int y=0;y<2;y++) for(int x=0;x<2;x++) if(fabric.nodes[y*2+x].hasOutput()) Serial.printf("(%d,%d)=%.1f\n",x,y,fabric.nodes[y*2+x].consumeOutput().data);
  delay(100);
}
