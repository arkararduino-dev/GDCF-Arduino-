#include "GDCF.h"
GDCFFabric fabric(3,1);
void setup(){
  Serial.begin(115200);
  fabric.setNode(0,0,PRIM_MAC); fabric.setNode(1,0,PRIM_RELU); fabric.setNode(2,0,PRIM_IDENTITY);
  fabric.setActivityPin(0,0,0); fabric.setActivityPin(1,0,1); fabric.setActivityPin(2,0,2);
  fabric.begin();
}
void loop(){
  int raw=analogRead(26); float val=raw/100.0f;
  fabric.inject(0,0,3,GDCFToken(true,0,0,val,0,0,0,0));
  fabric.inject(0,0,0,GDCFToken(true,0,0,0.5f,0,0,0,0));
  fabric.update();
  if(fabric.nodes[2].hasOutput()){
    float out=fabric.nodes[2].consumeOutput().data;
    Serial.println(out); digitalWrite(LED_BUILTIN, out>0?HIGH:LOW);
  }
  delay(50);
}
