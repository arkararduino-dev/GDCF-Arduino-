#include "GDCF.h"
GDCFFabric fabric(2,2);
void setup(){
  Serial.begin(115200);
  for(int y=0;y<2;y++) for(int x=0;x<2;x++) fabric.setNode(x,y,PRIM_IDENTITY);
  fabric.autoActivityPins(0); fabric.setInputTriggerPin(0,0,16); fabric.setInputTriggerPin(1,1,17); fabric.begin();
}
void loop(){
  fabric.update();
  for(int i=0;i<4;i++) if(fabric.nodes[i].hasOutput()) Serial.printf("Node(%d,%d): %.1f\n",i%2,i/2,fabric.nodes[i].consumeOutput().data);
  if(Serial.available()){
    char cmd=Serial.read();
    if(cmd=="1"){ fabric.inject(0,0,3,GDCFToken(true,0,0,99.0f,0,0,1,0)); Serial.println("Token to (1,0)"); }
    else if(cmd=="2"){ fabric.inject(0,0,3,GDCFToken(true,0,0,88.0f,0,0,0,1)); Serial.println("Token to (0,1)"); }
  }
  delay(5);
}
