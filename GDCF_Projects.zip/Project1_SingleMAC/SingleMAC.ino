#include "GDCF.h"
GDCFFabric fabric(1,1);
void setup(){
  Serial.begin(115200);
  fabric.setNode(0,0,PRIM_MAC);
  fabric.setActivityPin(0,0,0);
  fabric.setOutputPulsePin(0,0,1);
  fabric.begin();
  fabric.inject(0,0,3,GDCFToken(true,0,0,5.0f,0,0,0,0));
  fabric.inject(0,0,0,GDCFToken(true,0,0,3.0f,0,0,0,0));
}
void loop(){
  fabric.update();
  if(fabric.nodes[0].hasOutput()){
    Serial.println(fabric.nodes[0].consumeOutput().data);
  }
}
