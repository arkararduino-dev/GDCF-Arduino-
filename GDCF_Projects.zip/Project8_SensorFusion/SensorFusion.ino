#include "GDCF.h"
GDCFFabric fabric(2,1);
void setup(){
  Serial.begin(115200); fabric.setNode(0,0,PRIM_MAC); fabric.setNode(1,0,PRIM_IDENTITY);
  fabric.setActivityPin(0,0,0); fabric.setOutputPulsePin(1,0,6); fabric.begin();
}
void loop(){
  static unsigned long last=0;
  if(millis()-last>100){
    last=millis();
    float temp=analogRead(26)*(3.3f/1024.0f)*100.0f;
    float light=analogRead(27)/1024.0f;
    fabric.inject(0,0,0,GDCFToken(true,0,0,temp,0,0,0,0));
    fabric.inject(0,0,3,GDCFToken(true,0,0,0.7f,0,0,0,0));
  }
  fabric.update();
  if(fabric.nodes[1].hasOutput()){
    GDCFToken res=fabric.nodes[1].consumeOutput();
    if(res.data>30.0){ digitalWrite(6,HIGH); delay(200); digitalWrite(6,LOW); Serial.println("Alert!"); }
  }
}
